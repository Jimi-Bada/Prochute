// NavBar
let navBar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () => {
    navBar.classList.toggle('active');
}


// window.onscroll = () => {
//     navBar.classList.remove('active');
// }